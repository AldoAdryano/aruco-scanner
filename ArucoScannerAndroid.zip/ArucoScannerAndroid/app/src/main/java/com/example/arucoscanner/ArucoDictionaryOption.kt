package com.example.arucoscanner

data class ArucoDictionaryOption(
    val label: String,
    val dictionaryId: Int,
) {
    override fun toString(): String = label

    companion object {
        // Numeric values follow OpenCV's PREDEFINED_DICTIONARY_NAME enum.
        val supported = listOf(
            ArucoDictionaryOption("ArUco 4×4 — 50 marker", 0),
            ArucoDictionaryOption("ArUco 4×4 — 250 marker", 2),
            ArucoDictionaryOption("ArUco 5×5 — 100 marker", 5),
            ArucoDictionaryOption("ArUco 6×6 — 250 marker", 10),
            ArucoDictionaryOption("ArUco 7×7 — 250 marker", 14),
            ArucoDictionaryOption("ArUco Original", 16),
            ArucoDictionaryOption("AprilTag 36h11", 20),
        )
    }
}
