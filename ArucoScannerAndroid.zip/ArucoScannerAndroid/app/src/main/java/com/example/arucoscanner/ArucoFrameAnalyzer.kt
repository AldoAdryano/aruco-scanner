package com.example.arucoscanner

import android.graphics.Bitmap
import android.os.SystemClock
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import org.opencv.android.Utils
import org.opencv.core.Core
import org.opencv.core.Mat
import org.opencv.imgproc.Imgproc
import org.opencv.objdetect.ArucoDetector
import org.opencv.objdetect.DetectorParameters
import org.opencv.objdetect.Objdetect

class ArucoFrameAnalyzer(
    initialDictionaryId: Int,
    private val onFrameReady: (Bitmap, List<Int>, Long) -> Unit,
    private val onFailure: (String) -> Unit,
) : ImageAnalysis.Analyzer {

    private val detectorLock = Any()
    private var detector: ArucoDetector = createDetector(initialDictionaryId)
    private var lastProcessedAt = 0L
    private var lastErrorAt = 0L

    fun setDictionary(dictionaryId: Int) {
        synchronized(detectorLock) {
            detector = createDetector(dictionaryId)
        }
    }

    override fun analyze(image: ImageProxy) {
        val now = SystemClock.elapsedRealtime()

        // Batasi pemrosesan sekitar 12 FPS. CameraX tetap menyimpan frame terbaru.
        if (now - lastProcessedAt < 80L) {
            image.close()
            return
        }
        lastProcessedAt = now

        var sourceBitmapForCleanup: Bitmap? = null
        var sourceRgbaForCleanup: Mat? = null
        var rotatedRgbaForCleanup: Mat? = null
        var rgbForCleanup: Mat? = null
        var grayForCleanup: Mat? = null
        var idsForCleanup: Mat? = null
        val corners = mutableListOf<Mat>()

        try {
            val startedAt = SystemClock.elapsedRealtime()

            // CameraX menangani detail stride dan urutan kanal saat mengubah ImageProxy.
            val sourceBitmap = image.toBitmap()
            sourceBitmapForCleanup = sourceBitmap

            val sourceRgba = Mat()
            sourceRgbaForCleanup = sourceRgba
            Utils.bitmapToMat(sourceBitmap, sourceRgba)

            val rotatedRgba = rotate(sourceRgba, image.imageInfo.rotationDegrees)
            rotatedRgbaForCleanup = rotatedRgba

            val rgb = Mat()
            rgbForCleanup = rgb
            val gray = Mat()
            grayForCleanup = gray

            Imgproc.cvtColor(rotatedRgba, rgb, Imgproc.COLOR_RGBA2RGB)
            Imgproc.cvtColor(rotatedRgba, gray, Imgproc.COLOR_RGBA2GRAY)

            val ids = Mat()
            idsForCleanup = ids
            synchronized(detectorLock) {
                detector.detectMarkers(gray, corners, ids)
            }

            if (!ids.empty()) {
                Objdetect.drawDetectedMarkers(rgb, corners, ids)
            }

            val markerIds = buildList {
                for (row in 0 until ids.rows()) {
                    ids.get(row, 0)?.firstOrNull()?.toInt()?.let(::add)
                }
            }

            val outputBitmap = Bitmap.createBitmap(
                rgb.cols(),
                rgb.rows(),
                Bitmap.Config.ARGB_8888,
            )
            Utils.matToBitmap(rgb, outputBitmap)

            val processingTimeMs = SystemClock.elapsedRealtime() - startedAt
            onFrameReady(outputBitmap, markerIds, processingTimeMs)
        } catch (error: Exception) {
            val errorNow = SystemClock.elapsedRealtime()
            if (errorNow - lastErrorAt > 2_000L) {
                lastErrorAt = errorNow
                onFailure(error.message ?: error.javaClass.simpleName)
            }
        } finally {
            corners.forEach(Mat::release)
            idsForCleanup?.release()
            grayForCleanup?.release()
            rgbForCleanup?.release()
            rotatedRgbaForCleanup?.release()
            sourceRgbaForCleanup?.release()
            sourceBitmapForCleanup?.recycle()
            image.close()
        }
    }

    private fun createDetector(dictionaryId: Int): ArucoDetector {
        val dictionary = Objdetect.getPredefinedDictionary(dictionaryId)
        val parameters = DetectorParameters().apply {
            set_useAruco3Detection(true)
        }
        return ArucoDetector(dictionary, parameters)
    }

    private fun rotate(input: Mat, rotationDegrees: Int): Mat {
        val output = Mat()
        when (rotationDegrees) {
            90 -> Core.rotate(input, output, Core.ROTATE_90_CLOCKWISE)
            180 -> Core.rotate(input, output, Core.ROTATE_180)
            270 -> Core.rotate(input, output, Core.ROTATE_90_COUNTERCLOCKWISE)
            else -> input.copyTo(output)
        }
        return output
    }
}
