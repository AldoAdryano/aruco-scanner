package com.example.arucoscanner

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.util.Size
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import com.example.arucoscanner.databinding.ActivityMainBinding
import org.opencv.android.OpenCVLoader
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var cameraExecutor: ExecutorService
    private lateinit var frameAnalyzer: ArucoFrameAnalyzer

    private var camera: Camera? = null
    private var torchEnabled = false
    private var openCvReady = false

    private val cameraPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission(),
    ) { granted ->
        if (granted) {
            startCamera()
        } else {
            binding.statusText.text = getString(R.string.camera_permission_denied)
            Toast.makeText(
                this,
                R.string.camera_permission_required,
                Toast.LENGTH_LONG,
            ).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        cameraExecutor = Executors.newSingleThreadExecutor()
        openCvReady = initializeOpenCv()
        setupDictionarySpinner()
        setupTorchButton()

        if (!openCvReady) {
            binding.statusText.text = getString(R.string.opencv_failed)
            binding.torchButton.isEnabled = false
            return
        }

        when {
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.CAMERA,
            ) == PackageManager.PERMISSION_GRANTED -> startCamera()

            else -> cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    private fun initializeOpenCv(): Boolean {
        return try {
            OpenCVLoader.initLocal()
        } catch (_: UnsatisfiedLinkError) {
            false
        }
    }

    private fun setupDictionarySpinner() {
        val options = ArucoDictionaryOption.supported
        val adapter = ArrayAdapter(
            this,
            R.layout.spinner_item,
            options,
        ).apply {
            setDropDownViewResource(R.layout.spinner_dropdown_item)
        }

        binding.dictionarySpinner.adapter = adapter
        binding.dictionarySpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long,
            ) {
                if (::frameAnalyzer.isInitialized) {
                    frameAnalyzer.setDictionary(options[position].dictionaryId)
                    binding.detailText.text = "Kamus aktif: ${options[position].label}"
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>?) = Unit
        }
    }

    private fun setupTorchButton() {
        binding.torchButton.setOnClickListener {
            val activeCamera = camera ?: return@setOnClickListener
            if (!activeCamera.cameraInfo.hasFlashUnit()) {
                Toast.makeText(this, "Perangkat tidak memiliki lampu flash.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            torchEnabled = !torchEnabled
            activeCamera.cameraControl.enableTorch(torchEnabled)
            updateTorchButton()
        }
        binding.torchButton.isEnabled = false
    }

    private fun startCamera() {
        binding.statusText.text = getString(R.string.starting_camera)
        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)

        cameraProviderFuture.addListener({
            try {
                val cameraProvider = cameraProviderFuture.get()
                val selectedIndex = binding.dictionarySpinner.selectedItemPosition
                    .coerceIn(ArucoDictionaryOption.supported.indices)
                val selectedDictionary = ArucoDictionaryOption.supported[selectedIndex]

                frameAnalyzer = ArucoFrameAnalyzer(
                    initialDictionaryId = selectedDictionary.dictionaryId,
                    onFrameReady = { bitmap, markerIds, processingTimeMs ->
                        runOnUiThread {
                            if (isDestroyed || isFinishing) return@runOnUiThread
                            binding.cameraImage.setImageBitmap(bitmap)

                            if (markerIds.isEmpty()) {
                                binding.statusText.text = getString(R.string.no_marker)
                                binding.detailText.text = "Analisis ${processingTimeMs} ms"
                            } else {
                                binding.statusText.text =
                                    "${markerIds.size} marker terdeteksi"
                                binding.detailText.text =
                                    "ID: ${markerIds.joinToString()} • ${processingTimeMs} ms"
                            }
                        }
                    },
                    onFailure = { message ->
                        runOnUiThread {
                            if (isDestroyed || isFinishing) return@runOnUiThread
                            binding.statusText.text = "Pemindaian gagal"
                            binding.detailText.text = message
                        }
                    },
                )

                val imageAnalysis = ImageAnalysis.Builder()
                    .setTargetResolution(Size(1280, 720))
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                    .build()
                    .also {
                        it.setAnalyzer(cameraExecutor, frameAnalyzer)
                    }

                cameraProvider.unbindAll()
                camera = cameraProvider.bindToLifecycle(
                    this,
                    CameraSelector.DEFAULT_BACK_CAMERA,
                    imageAnalysis,
                )

                binding.torchButton.isEnabled = camera?.cameraInfo?.hasFlashUnit() == true
                binding.statusText.text = getString(R.string.no_marker)
                binding.detailText.text = "Kamus aktif: ${selectedDictionary.label}"
            } catch (error: Exception) {
                binding.statusText.text = "Kamera gagal dijalankan"
                binding.detailText.text = error.message ?: error.javaClass.simpleName
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun updateTorchButton() {
        binding.torchButton.text = if (torchEnabled) "Senter: ON" else "Senter"
    }

    override fun onDestroy() {
        super.onDestroy()
        cameraExecutor.shutdown()
    }
}
