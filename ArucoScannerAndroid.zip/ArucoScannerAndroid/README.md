# ArUco Scanner Android

Aplikasi Android sederhana untuk mendeteksi marker ArUco secara real-time menggunakan kamera belakang. Proyek ini dirancang agar APK dapat dibangun sepenuhnya melalui GitHub Actions tanpa Android Studio lokal.

## Fitur

- Pemindaian marker melalui kamera belakang.
- Menampilkan garis batas dan ID marker pada gambar kamera.
- Menampilkan jumlah marker serta waktu pemrosesan tiap frame.
- Pilihan kamus ArUco 4×4, 5×5, 6×6, 7×7, ArUco Original, dan AprilTag 36h11.
- Tombol senter untuk perangkat yang memiliki flash.
- Build APK otomatis melalui GitHub Actions.
- Dua marker contoh untuk pengujian pada folder `sample-markers`.

## Teknologi

- Kotlin
- CameraX 1.6.1
- OpenCV Android AAR 4.14.0
- Android Gradle Plugin 8.10.0
- Compile/target SDK 36
- Minimum Android 7.0, API 24

## Build hanya menggunakan GitHub

1. Buat repository GitHub kosong, misalnya `aruco-scanner-android`.
2. Ekstrak ZIP proyek ini.
3. Unggah seluruh isi folder hasil ekstraksi ke root repository. Pastikan folder `.github/workflows` ikut terunggah.
4. Buka tab **Actions** pada repository.
5. Pilih workflow **Build Android APK**.
6. Tekan **Run workflow**, atau cukup lakukan push ke branch `main`.
7. Setelah workflow selesai, buka hasil workflow tersebut.
8. Pada bagian **Artifacts**, unduh `aruco-scanner-debug-apk`.
9. Ekstrak artifact, lalu instal `app-debug.apk` pada ponsel Android.
10. Tampilkan salah satu PNG pada folder `sample-markers` di layar lain, lalu pilih kamus **ArUco 4×4 — 50 marker** untuk menguji pemindaian.

APK debug sudah ditandatangani otomatis oleh Android debug keystore, sehingga dapat langsung dipasang. Aktifkan izin instalasi dari sumber tidak dikenal bila Android memintanya.

## Struktur penting

```text
.github/workflows/build-apk.yml     Workflow pembuat APK
app/src/main/AndroidManifest.xml    Izin kamera dan konfigurasi aplikasi
app/src/main/java/.../MainActivity.kt
app/src/main/java/.../ArucoFrameAnalyzer.kt
```

## Mengganti nama aplikasi

Ubah nilai berikut:

- Nama yang tampil: `app/src/main/res/values/strings.xml`
- Application ID: `applicationId` dan `namespace` pada `app/build.gradle.kts`
- Package Kotlin: folder dan deklarasi package pada file `.kt`

## Catatan teknis

Versi ini melakukan deteksi marker dan pembacaan ID. Pengukuran jarak, posisi 3D, atau sudut marker belum diaktifkan karena fitur tersebut memerlukan ukuran fisik marker dan parameter kalibrasi kamera masing-masing perangkat.

Kualitas deteksi paling dipengaruhi oleh pencahayaan, ketajaman cetakan, ukuran marker dalam frame, motion blur, dan kesesuaian kamus yang dipilih.
